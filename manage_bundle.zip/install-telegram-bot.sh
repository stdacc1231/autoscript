#!/usr/bin/env bash
set -euo pipefail

SAFE_PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
PATH="${SAFE_PATH}"
export PATH

on_err() {
  local rc="$?"
  echo "[ERROR] line ${BASH_LINENO[0]}: command failed (exit ${rc})" >&2
  exit "${rc}"
}
trap on_err ERR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

telegram_bootstrap_path_trusted() {
  local target="${1:-}" current owner mode
  [[ -n "${target}" && -e "${target}" ]] || return 1
  if [[ "$(id -u)" -ne 0 ]]; then
    return 0
  fi

  current="$(readlink -f -- "${target}" 2>/dev/null || true)"
  [[ -n "${current}" ]] || return 1
  while :; do
    [[ -e "${current}" ]] || return 1
    [[ -L "${current}" ]] && return 1
    owner="$(stat -c '%u' "${current}" 2>/dev/null || echo 1)"
    mode="$(stat -c '%A' "${current}" 2>/dev/null || echo '----------')"
    [[ "${owner}" == "0" ]] || return 1
    [[ "${mode:5:1}" != "w" && "${mode:8:1}" != "w" ]] || return 1
    [[ "${current}" == "/" ]] && break
    current="$(dirname -- "${current}")"
  done
  return 0
}

TELEGRAM_LICENSE_ENV_FILE=""
for TELEGRAM_LICENSE_ENV_CANDIDATE in \
  "${SCRIPT_DIR}/opt/setup/core/env.sh" \
  "/opt/setup/core/env.sh" \
  "/usr/local/lib/autoscript-setup/opt/setup/core/env.sh"
do
  if [[ -f "${TELEGRAM_LICENSE_ENV_CANDIDATE}" ]]; then
    TELEGRAM_LICENSE_ENV_FILE="${TELEGRAM_LICENSE_ENV_CANDIDATE}"
    break
  fi
done
if [[ -n "${TELEGRAM_LICENSE_ENV_FILE}" ]]; then
  if ! telegram_bootstrap_path_trusted "${TELEGRAM_LICENSE_ENV_FILE}"; then
    echo "[ERROR] env.sh lisensi tidak trusted: ${TELEGRAM_LICENSE_ENV_FILE}" >&2
    exit 1
  fi
  # shellcheck disable=SC1090
  . "${TELEGRAM_LICENSE_ENV_FILE}"
fi

if [[ -t 1 ]]; then
  UI_RESET='\033[0m'
  UI_BOLD='\033[1m'
  UI_ACCENT='\033[0;36m'
  UI_MUTED='\033[0;37m'
  UI_WARN='\033[1;33m'
  UI_ERR='\033[0;31m'
  UI_OK='\033[0;32m'
else
  UI_RESET=''
  UI_BOLD=''
  UI_ACCENT=''
  UI_MUTED=''
  UI_WARN=''
  UI_ERR=''
  UI_OK=''
fi

format_host_for_url() {
  local host="$1"
  if [[ "${host}" == *:* && "${host}" != \[*\] ]]; then
    printf '[%s]\n' "${host}"
    return
  fi
  printf '%s\n' "${host}"
}

BOT_HOME_EXPLICIT=0
[[ -v BOT_HOME ]] && BOT_HOME_EXPLICIT=1
BOT_ENV_DIR_EXPLICIT=0
[[ -v BOT_ENV_DIR ]] && BOT_ENV_DIR_EXPLICIT=1
BOT_ENV_FILE_EXPLICIT=0
[[ -v BOT_ENV_FILE ]] && BOT_ENV_FILE_EXPLICIT=1
BOT_STATE_DIR_EXPLICIT=0
[[ -v BOT_STATE_DIR ]] && BOT_STATE_DIR_EXPLICIT=1
BOT_LOG_DIR_EXPLICIT=0
[[ -v BOT_LOG_DIR ]] && BOT_LOG_DIR_EXPLICIT=1
GATEWAY_RUN_USER_EXPLICIT=0
[[ -v GATEWAY_RUN_USER ]] && GATEWAY_RUN_USER_EXPLICIT=1
BACKEND_HOST_EXPLICIT=0
[[ -v BACKEND_HOST ]] && BACKEND_HOST_EXPLICIT=1
BACKEND_PORT_EXPLICIT=0
[[ -v BACKEND_PORT ]] && BACKEND_PORT_EXPLICIT=1
BACKEND_BASE_URL_EXPLICIT=0
[[ -v BACKEND_BASE_URL ]] && BACKEND_BASE_URL_EXPLICIT=1

BOT_HOME="${BOT_HOME:-/opt/bot-telegram}"
BOT_ENV_DIR="${BOT_ENV_DIR:-/etc/bot-telegram}"
BOT_ENV_FILE="${BOT_ENV_FILE:-${BOT_ENV_DIR}/bot.env}"
BOT_STATE_DIR="${BOT_STATE_DIR:-/var/lib/bot-telegram}"
BOT_LOG_DIR="${BOT_LOG_DIR:-/var/log/bot-telegram}"
GATEWAY_RUN_USER="${GATEWAY_RUN_USER:-bot-telegram-gateway}"
BACKEND_HOST="${BACKEND_HOST:-127.0.0.1}"
BACKEND_PORT="${BACKEND_PORT:-7081}"
BACKEND_BASE_URL="${BACKEND_BASE_URL:-}"
if [[ -z "${BACKEND_BASE_URL}" ]]; then
  BACKEND_BASE_URL="http://$(format_host_for_url "${BACKEND_HOST}"):${BACKEND_PORT}"
fi

BACKEND_SERVICE="bot-telegram-backend"
GATEWAY_SERVICE="bot-telegram-gateway"
MONITOR_SERVICE="bot-telegram-monitor"

SRC_OWNER="${BOT_SOURCE_OWNER:-superdecrypt-dev}"
SRC_REPO="${BOT_SOURCE_REPO:-autoscript}"
SRC_REF="${BOT_SOURCE_REF:-main}"
SRC_ARCHIVE_DEFAULT_URL="https://github.com/${SRC_OWNER}/${SRC_REPO}/raw/${SRC_REF}/bot_telegram.zip"
SRC_ARCHIVE_URL="${BOT_SOURCE_ARCHIVE_URL:-${SRC_ARCHIVE_DEFAULT_URL}}"
SRC_LOCAL_DIR="${BOT_SOURCE_LOCAL_DIR:-}"
BOT_DIR_MARKER=".bot-telegram-owned"

OS_DEPS=(
  curl
  ca-certificates
  tar
  unzip
  jq
  rsync
  git
  bash
  python3
  python3-venv
  python3-pip
)

log() { echo -e "${UI_ACCENT}[telegram-installer]${UI_RESET} $*"; }
ok() { echo -e "${UI_OK}[OK]${UI_RESET} $*"; }
warn() { echo -e "${UI_WARN}[WARN]${UI_RESET} $*" >&2; }
die() { echo -e "${UI_ERR}[ERROR]${UI_RESET} $*" >&2; exit 1; }
BACK_INPUT_SENTINEL="__BACK__$(date +%s%N)_${RANDOM}_${RANDOM}__"
CONFIGURE_ENV_CANCELLED=0

telegram_license_guard_bin_path() {
  printf '%s\n' "/usr/local/bin/autoscript-license-check"
}

telegram_license_trusted_default_api_url() {
  printf '%s\n' "https://autoscript-license.minidecrypt.workers.dev/api/v1/license/check"
}

telegram_license_config_file_path() {
  printf '%s\n' "/etc/autoscript/license/config.env"
}

telegram_license_config_get() {
  local key="$1"
  local env_file=""
  env_file="$(telegram_license_config_file_path)"
  [[ -r "${env_file}" ]] || return 1
  awk -F= -v key="${key}" '
    $1 == key {
      sub(/^[[:space:]]+/, "", $2)
      sub(/[[:space:]]+$/, "", $2)
      print $2
      exit
    }
  ' "${env_file}"
}

telegram_license_guard_api_url() {
  local trusted_default=""
  trusted_default="$(telegram_license_trusted_default_api_url)"
  printf '%s\n' "${trusted_default}"
}

telegram_license_guard_enabled() {
  local api_url=""
  local env_file=""
  local license_bin=""
  local license_service="${AUTOSCRIPT_LICENSE_SERVICE:-autoscript-license-enforcer.service}"
  local license_timer="${AUTOSCRIPT_LICENSE_TIMER:-autoscript-license-enforcer.timer}"

  env_file="$(telegram_license_config_file_path)"
  license_bin="$(telegram_license_guard_bin_path)"
  api_url="$(telegram_license_guard_api_url)"
  if [[ -n "${api_url}" ]]; then
    return 0
  fi
  [[ -e "${env_file}" || -x "${license_bin}" || -e "/etc/systemd/system/${license_service}" || -e "/etc/systemd/system/${license_timer}" ]]
}

telegram_license_guard_preflight() {
  local action="${1:-menu}"
  local license_bin=""
  local api_url=""
  local config_file=""
  local default_api_url=""
  local license_output=""
  local license_reason=""

  if ! telegram_license_guard_enabled; then
    return 0
  fi

  license_bin="$(telegram_license_guard_bin_path)"
  api_url="$(telegram_license_guard_api_url)"
  config_file="$(telegram_license_config_file_path)"
  default_api_url="$(telegram_license_trusted_default_api_url)"
  if [[ ! -x "${license_bin}" ]]; then
    die "Binary license guard tidak ditemukan: ${license_bin}"
  fi
  if ! telegram_bootstrap_path_trusted "${license_bin}"; then
    die "Binary license guard tidak trusted: ${license_bin}"
  fi
  if ! license_output="$(
    AUTOSCRIPT_LICENSE_DEFAULT_API_URL="${default_api_url}" \
      AUTOSCRIPT_LICENSE_API_URL="${api_url}" \
      AUTOSCRIPT_LICENSE_CONFIG_FILE="${config_file}" \
      "${license_bin}" check --stage manage --allow-disabled=false 2>&1
  )"; then
    license_reason="${license_output##*$'\n'}"
    if [[ -n "${license_reason}" ]]; then
      die "Akses ${action} ditolak oleh license guard. ${license_reason}"
    fi
    die "Akses ${action} ditolak oleh license guard."
  fi
}

hr() {
  local w="${COLUMNS:-80}"
  local line
  if [[ ! "${w}" =~ ^[0-9]+$ ]]; then
    w=80
  fi
  if (( w < 60 )); then
    w=60
  fi
  printf -v line '%*s' "${w}" ''
  line="${line// /-}"
  echo -e "${UI_MUTED}${line}${UI_RESET}"
}

safe_clear() {
  if [[ -t 1 ]] && command -v clear >/dev/null 2>&1; then
    clear || true
  fi
}

pause() {
  read -r -p "Tekan ENTER untuk kembali..." _ || true
}

run_action() {
  # Jalankan aksi dalam subshell agar error tidak langsung menutup menu.
  # args: label cmd...
  local label="$1"
  shift || true

  local rc=0
  set +e
  ( set -euo pipefail; "$@" )
  rc=$?
  set -euo pipefail

  if (( rc != 0 )); then
    warn "${label} gagal (rc=${rc})."
  fi
  return 0
}

is_back_choice() {
  local v="${1:-}"
  v="$(echo "${v}" | tr '[:upper:]' '[:lower:]')"
  [[ "${v}" == "0" || "${v}" == "kembali" || "${v}" == "k" || "${v}" == "back" || "${v}" == "b" ]]
}

cancel_env_config() {
  CONFIGURE_ENV_CANCELLED=1
  warn "Konfigurasi env dibatalkan (kembali)."
}

need_root() {
  [[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Jalankan script sebagai root."
}

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

mark_bot_owned_dir() {
  local dir="$1"
  [[ -d "${dir}" ]] || return 0
  printf 'owned-by=install-telegram-bot\n' > "${dir}/${BOT_DIR_MARKER}"
  chmod 600 "${dir}/${BOT_DIR_MARKER}" >/dev/null 2>&1 || true
}

normalize_path() {
  local path="$1"
  if command_exists realpath; then
    realpath -m -- "${path}" 2>/dev/null || printf '%s\n' "${path}"
    return 0
  fi
  if command_exists readlink; then
    readlink -m -- "${path}" 2>/dev/null || printf '%s\n' "${path}"
    return 0
  fi
  printf '%s\n' "${path}"
}

assert_safe_delete_target() {
  local target="$1"
  local label="${2:-path}"
  local resolved

  [[ -n "${target}" ]] || die "Path ${label} kosong; batalkan uninstall."
  resolved="$(normalize_path "${target}")"
  [[ -n "${resolved}" ]] || die "Path ${label} tidak valid: ${target}"
  [[ "${resolved}" == /* ]] || die "Path ${label} harus absolut: ${resolved}"
  if [[ "${resolved}" == *$'\n'* || "${resolved}" == *$'\r'* ]]; then
    die "Path ${label} tidak valid (mengandung newline)."
  fi

  case "${resolved}" in
    "/"|"/."|"/.."|"/bin"|"/boot"|"/dev"|"/etc"|"/home"|"/lib"|"/lib64"|"/media"|"/mnt"|"/opt"|"/proc"|"/root"|"/run"|"/sbin"|"/srv"|"/sys"|"/tmp"|"/usr"|"/var")
      die "Path ${label} terlalu berbahaya untuk dihapus: ${resolved}"
      ;;
  esac
}

mask_secret() {
  local s="$1"
  local n
  n="${#s}"
  if [[ -z "$s" ]]; then
    echo "(kosong)"
    return 0
  fi
  if (( n <= 6 )); then
    echo "******"
    return 0
  fi
  echo "${s:0:3}...${s: -3}"
}

get_env_value() {
  local key="$1"
  local file="$2"
  [[ -f "$file" ]] || return 0
  awk -v key="$key" -F= '$1==key {print substr($0, index($0,"=")+1); exit}' "$file"
}

set_env_value() {
  local key="$1"
  local value="$2"
  local file="$3"
  local tmp

  if [[ "${value}" == *$'\n'* || "${value}" == *$'\r'* ]]; then
    die "Nilai env untuk ${key} tidak valid (mengandung newline)."
  fi

  mkdir -p "$(dirname "$file")"
  [[ -f "$file" ]] || touch "$file"

  tmp="$(mktemp)"
  awk -v key="$key" -v value="$value" '
    BEGIN { done=0 }
    $0 ~ ("^" key "=") { print key "=" value; done=1; next }
    { print }
    END { if (!done) print key "=" value }
  ' "$file" > "$tmp"

  install -m 600 "$tmp" "$file"
  rm -f "$tmp" >/dev/null 2>&1 || true
}

unset_env_value() {
  local key="$1"
  local file="$2"
  local tmp

  [[ -f "$file" ]] || return 0
  tmp="$(mktemp)"
  awk -v key="$key" '
    $0 ~ ("^" key "=") { next }
    { print }
  ' "$file" > "$tmp"

  install -m 600 "$tmp" "$file"
  rm -f "$tmp" >/dev/null 2>&1 || true
}

resolve_persisted_env_file() {
  local candidate unit

  if [[ -n "${BOT_ENV_FILE:-}" && -f "${BOT_ENV_FILE}" ]]; then
    printf '%s\n' "${BOT_ENV_FILE}"
    return
  fi

  if command_exists systemctl; then
    for unit in "${GATEWAY_SERVICE}" "${BACKEND_SERVICE}" "${MONITOR_SERVICE}"; do
      candidate="$(systemctl cat "${unit}" 2>/dev/null | awk '
        /^[[:space:]]*EnvironmentFile=/ {
          value = substr($0, index($0, "=") + 1)
          sub(/^-/, "", value)
          if (value != "") print value
        }
      ' | tail -n1)"
      if [[ -n "${candidate}" && -f "${candidate}" ]]; then
        printf '%s\n' "${candidate}"
        return
      fi
    done
  fi
}

load_persisted_runtime_config() {
  local env_file value

  env_file="$(resolve_persisted_env_file || true)"
  [[ -n "${env_file}" && -f "${env_file}" ]] || return 0

  if (( BOT_ENV_FILE_EXPLICIT == 0 )); then
    value="$(get_env_value BOT_ENV_FILE "${env_file}")"
    BOT_ENV_FILE="${value:-${env_file}}"
  fi
  if (( BOT_ENV_DIR_EXPLICIT == 0 )); then
    BOT_ENV_DIR="$(dirname "${BOT_ENV_FILE}")"
  fi
  if (( BOT_HOME_EXPLICIT == 0 )); then
    value="$(get_env_value BOT_HOME "${env_file}")"
    [[ -n "${value}" ]] && BOT_HOME="${value}"
  fi
  if (( BOT_STATE_DIR_EXPLICIT == 0 )); then
    value="$(get_env_value BOT_STATE_DIR "${env_file}")"
    [[ -n "${value}" ]] && BOT_STATE_DIR="${value}"
  fi
  if (( BOT_LOG_DIR_EXPLICIT == 0 )); then
    value="$(get_env_value BOT_LOG_DIR "${env_file}")"
    [[ -n "${value}" ]] && BOT_LOG_DIR="${value}"
  fi
  if (( GATEWAY_RUN_USER_EXPLICIT == 0 )); then
    value="$(get_env_value GATEWAY_RUN_USER "${env_file}")"
    [[ -n "${value}" ]] && GATEWAY_RUN_USER="${value}"
  fi
  if (( BACKEND_HOST_EXPLICIT == 0 )); then
    value="$(get_env_value BACKEND_HOST "${env_file}")"
    [[ -n "${value}" ]] && BACKEND_HOST="${value}"
  fi
  if (( BACKEND_PORT_EXPLICIT == 0 )); then
    value="$(get_env_value BACKEND_PORT "${env_file}")"
    [[ -n "${value}" ]] && BACKEND_PORT="${value}"
  fi
  if (( BACKEND_BASE_URL_EXPLICIT == 0 )); then
    value="$(get_env_value BACKEND_BASE_URL "${env_file}")"
    if [[ -n "${value}" ]]; then
      BACKEND_BASE_URL="${value}"
    else
      BACKEND_BASE_URL="http://$(format_host_for_url "${BACKEND_HOST}"):${BACKEND_PORT}"
    fi
  fi
}

load_persisted_runtime_config

prompt_with_default() {
  local prompt="$1"
  local def="$2"
  local out
  read -r -p "${prompt} [${def}]: " out || true
  echo "${out:-$def}"
}

prompt_with_default_or_back() {
  local prompt="$1"
  local def="$2"
  local out
  read -r -p "${prompt} [${def}] (atau kembali): " out || true
  if is_back_choice "${out}"; then
    echo "${BACK_INPUT_SENTINEL}"
    return 0
  fi
  echo "${out:-$def}"
}

prompt_yes_no() {
  local prompt="$1"
  local ans
  while true; do
    if ! read -r -p "${prompt} (y/n): " ans; then
      echo
      warn "Input ditutup (EOF). Aksi dibatalkan."
      return 1
    fi
    case "${ans,,}" in
      y|yes) return 0 ;;
      n|no) return 1 ;;
      *) echo "Masukkan y atau n." ;;
    esac
  done
}

prompt_yes_no_or_back() {
  local prompt="$1"
  local ans
  while true; do
    if ! read -r -p "${prompt} (y/n/kembali): " ans; then
      echo
      warn "Input ditutup (EOF). Kembali ke menu."
      return 2
    fi
    case "${ans,,}" in
      y|yes) return 0 ;;
      n|no) return 1 ;;
      0|kembali|k|back|b) return 2 ;;
      *) echo "Masukkan y, n, atau kembali." ;;
    esac
  done
}

prompt_secret() {
  local prompt="$1"
  local out
  read -r -s -p "${prompt}: " out || true
  # Tampilkan newline prompt ke stderr agar command substitution tidak menangkapnya.
  printf '\n' >&2
  printf '%s\n' "$out"
}

prompt_secret_or_back() {
  local prompt="$1"
  local out
  read -r -s -p "${prompt} (atau kembali): " out || true
  # Tampilkan newline prompt ke stderr agar command substitution tidak menangkapnya.
  printf '\n' >&2
  if is_back_choice "${out}"; then
    printf '%s\n' "${BACK_INPUT_SENTINEL}"
    return 0
  fi
  printf '%s\n' "$out"
}

generate_secret() {
  if command_exists openssl; then
    openssl rand -hex 24
  elif [[ -r /dev/urandom ]] && command_exists od; then
    od -An -N24 -tx1 /dev/urandom | tr -d ' \n'
  else
    printf '%s%06d\n' "$(date +%s%N)" "$$"
  fi
}

ensure_env_file() {
  mkdir -p "${BOT_HOME}" "${BOT_ENV_DIR}" "${BOT_STATE_DIR}" "${BOT_LOG_DIR}"
  mark_bot_owned_dir "${BOT_HOME}"
  mark_bot_owned_dir "${BOT_ENV_DIR}"
  mark_bot_owned_dir "${BOT_STATE_DIR}"
  mark_bot_owned_dir "${BOT_LOG_DIR}"

  if [[ ! -f "${BOT_ENV_FILE}" ]]; then
    cat > "${BOT_ENV_FILE}" <<ENVEOF
BOT_HOME=${BOT_HOME}
BOT_ENV_FILE=${BOT_ENV_FILE}
BOT_STATE_DIR=${BOT_STATE_DIR}
BOT_LOG_DIR=${BOT_LOG_DIR}
GATEWAY_RUN_USER=${GATEWAY_RUN_USER}
INTERNAL_SHARED_SECRET=
TELEGRAM_BOT_TOKEN=
TELEGRAM_BOT_USERNAME=
TELEGRAM_DEFAULT_CHAT_ID=
TELEGRAM_ADMIN_CHAT_IDS=
TELEGRAM_ADMIN_USER_IDS=
TELEGRAM_ALLOW_UNRESTRICTED_ACCESS=false
TELEGRAM_ACTION_COOLDOWN_SECONDS=1
TELEGRAM_CLEANUP_COOLDOWN_SECONDS=30
TELEGRAM_MAX_INPUT_LENGTH=2048
BACKEND_BASE_URL=${BACKEND_BASE_URL}
BACKEND_HOST=${BACKEND_HOST}
BACKEND_PORT=${BACKEND_PORT}
COMMANDS_FILE=${BOT_HOME}/shared/commands.json
ENVEOF
    chmod 600 "${BOT_ENV_FILE}"
    ok "File env dibuat: ${BOT_ENV_FILE}"
  else
    chmod 600 "${BOT_ENV_FILE}" || true
  fi

  if [[ -z "$(get_env_value BOT_HOME "${BOT_ENV_FILE}")" ]]; then
    set_env_value BOT_HOME "${BOT_HOME}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value BOT_ENV_FILE "${BOT_ENV_FILE}")" ]]; then
    set_env_value BOT_ENV_FILE "${BOT_ENV_FILE}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value BOT_STATE_DIR "${BOT_ENV_FILE}")" ]]; then
    set_env_value BOT_STATE_DIR "${BOT_STATE_DIR}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value BOT_LOG_DIR "${BOT_ENV_FILE}")" ]]; then
    set_env_value BOT_LOG_DIR "${BOT_LOG_DIR}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value GATEWAY_RUN_USER "${BOT_ENV_FILE}")" ]]; then
    set_env_value GATEWAY_RUN_USER "${GATEWAY_RUN_USER}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value BACKEND_BASE_URL "${BOT_ENV_FILE}")" ]]; then
    set_env_value BACKEND_BASE_URL "${BACKEND_BASE_URL}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value BACKEND_HOST "${BOT_ENV_FILE}")" ]]; then
    set_env_value BACKEND_HOST "${BACKEND_HOST}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value BACKEND_PORT "${BOT_ENV_FILE}")" ]]; then
    set_env_value BACKEND_PORT "${BACKEND_PORT}" "${BOT_ENV_FILE}"
  fi
  if [[ -z "$(get_env_value COMMANDS_FILE "${BOT_ENV_FILE}")" ]]; then
    set_env_value COMMANDS_FILE "${BOT_HOME}/shared/commands.json" "${BOT_ENV_FILE}"
  fi
}

validate_required_env() {
  local missing=()
  local key val admin_user_ids allow_unrestricted
  for key in INTERNAL_SHARED_SECRET TELEGRAM_BOT_TOKEN TELEGRAM_ADMIN_USER_IDS; do
    val="$(get_env_value "$key" "${BOT_ENV_FILE}")"
    [[ -n "${val}" ]] || missing+=("$key")
  done

  if (( ${#missing[@]} > 0 )); then
    warn "Env belum lengkap: ${missing[*]}"
    return 1
  fi

  admin_user_ids="$(get_env_value TELEGRAM_ADMIN_USER_IDS "${BOT_ENV_FILE}")"
  allow_unrestricted="$(printf '%s' "$(get_env_value TELEGRAM_ALLOW_UNRESTRICTED_ACCESS "${BOT_ENV_FILE}")" | tr '[:upper:]' '[:lower:]')"
  if [[ -z "${admin_user_ids}" ]]; then
    warn "TELEGRAM_ADMIN_USER_IDS wajib diisi agar bot hanya bisa dipakai admin."
    return 1
  fi
  if [[ "${allow_unrestricted}" == "true" ]]; then
    warn "TELEGRAM_ALLOW_UNRESTRICTED_ACCESS=true tidak diizinkan untuk mode admin-only."
    return 1
  fi
  return 0
}

service_unit_exists() {
  local svc="$1"
  systemctl cat "${svc}.service" >/dev/null 2>&1
}

timer_unit_exists() {
  local timer="$1"
  systemctl cat "${timer}.timer" >/dev/null 2>&1
}

unit_exists_full() {
  local unit="$1"
  systemctl cat "${unit}" >/dev/null 2>&1
}

unit_state() {
  local unit="$1"
  systemctl is-active "${unit}" 2>/dev/null || true
}

restart_unit_checked() {
  local unit="$1"
  unit_exists_full "${unit}" || die "Unit tidak ditemukan: ${unit}"
  systemctl restart "${unit}" >/dev/null 2>&1 || die "Gagal restart unit: ${unit}"
  local state
  state="$(unit_state "${unit}")"
  [[ "${state}" == "active" ]] || die "Unit ${unit} tidak aktif setelah restart (state=${state:-unknown})."
}

stop_unit_checked() {
  local unit="$1"
  if ! unit_exists_full "${unit}"; then
    return 0
  fi
  systemctl stop "${unit}" >/dev/null 2>&1 || die "Gagal menghentikan unit: ${unit}"
  local state
  state="$(unit_state "${unit}")"
  case "${state}" in
    inactive|failed|unknown)
      return 0
      ;;
  esac
  die "Unit ${unit} masih berjalan setelah stop (state=${state:-unknown})."
}

disable_unit_checked() {
  local unit="$1"
  if ! unit_exists_full "${unit}"; then
    return 0
  fi
  systemctl disable "${unit}" >/dev/null 2>&1 || die "Gagal disable unit: ${unit}"
}

show_service_status() {
  local svc="$1"
  local active enabled

  active="$(systemctl is-active "${svc}" 2>/dev/null || true)"
  enabled="$(systemctl is-enabled "${svc}" 2>/dev/null || true)"

  [[ -n "${active}" ]] || active="unknown"
  [[ -n "${enabled}" ]] || enabled="unknown"

  printf "%-24s active=%-10s enabled=%s\n" "${svc}" "${active}" "${enabled}"
}

install_dependencies() {
  need_root

  if ! command_exists apt-get; then
    die "Script ini saat ini mendukung distro berbasis apt (Ubuntu/Debian)."
  fi

  export DEBIAN_FRONTEND=noninteractive
  log "Install dependency OS/runtime..."
  apt-get update -y
  apt-get install -y "${OS_DEPS[@]}"

  ok "Dependency berhasil dipasang."
  echo "Versi runtime:"
  echo "- python3: $(python3 --version 2>/dev/null || echo 'n/a')"
}

configure_env_interactive() {
  need_root
  ensure_env_file
  CONFIGURE_ENV_CANCELLED=0

  local current_token current_secret current_bot_username current_default_chat_id current_admin_chat_ids current_admin_user_ids
  local token bot_username default_chat_id admin_chat_ids admin_user_ids secret_input
  local final_token final_secret staged_env

  current_token="$(get_env_value TELEGRAM_BOT_TOKEN "${BOT_ENV_FILE}")"
  current_secret="$(get_env_value INTERNAL_SHARED_SECRET "${BOT_ENV_FILE}")"
  current_bot_username="$(get_env_value TELEGRAM_BOT_USERNAME "${BOT_ENV_FILE}")"
  current_default_chat_id="$(get_env_value TELEGRAM_DEFAULT_CHAT_ID "${BOT_ENV_FILE}")"
  current_admin_chat_ids="$(get_env_value TELEGRAM_ADMIN_CHAT_IDS "${BOT_ENV_FILE}")"
  current_admin_user_ids="$(get_env_value TELEGRAM_ADMIN_USER_IDS "${BOT_ENV_FILE}")"
  current_allow_unrestricted="$(get_env_value TELEGRAM_ALLOW_UNRESTRICTED_ACCESS "${BOT_ENV_FILE}")"

  echo "Konfigurasi env: ${BOT_ENV_FILE}"
  echo "- TELEGRAM_BOT_TOKEN: $(mask_secret "${current_token}")"
  echo "- INTERNAL_SHARED_SECRET: $(mask_secret "${current_secret}")"
  echo "- TELEGRAM_ADMIN_USER_IDS: ${current_admin_user_ids:-'(kosong)'}"
  echo "- TELEGRAM_ALLOW_UNRESTRICTED_ACCESS: dipaksa false"

  token="$(prompt_secret_or_back "Masukkan TELEGRAM_BOT_TOKEN (kosong=pertahankan yang lama)")"
  if [[ "${token}" == "${BACK_INPUT_SENTINEL}" ]]; then
    cancel_env_config
    return 0
  fi
  if [[ -n "${token}" ]]; then
    final_token="${token}"
  else
    final_token="${current_token}"
  fi

  # Variabel ini tetap disimpan di env bila sudah ada, tetapi tidak lagi
  # diminta dari installer interaktif.
  bot_username="${current_bot_username}"
  default_chat_id="${current_default_chat_id}"
  admin_chat_ids="${current_admin_chat_ids}"
  admin_user_ids="$(prompt_with_default_or_back "TELEGRAM_ADMIN_USER_IDS (wajib, pisahkan koma)" "${current_admin_user_ids}")"
  if [[ "${admin_user_ids}" == "${BACK_INPUT_SENTINEL}" ]]; then
    cancel_env_config
    return 0
  fi
  admin_user_ids="$(printf '%s' "${admin_user_ids}" | tr -d '[:space:]')"
  if [[ -z "${admin_user_ids}" ]]; then
    warn "TELEGRAM_ADMIN_USER_IDS wajib diisi. Gunakan user ID Telegram numerik admin."
    return 1
  fi

  if [[ -z "${current_secret}" ]]; then
    secret_input="$(generate_secret)"
    final_secret="${secret_input}"
    ok "INTERNAL_SHARED_SECRET digenerate otomatis."
  else
    final_secret="${current_secret}"
  fi

  staged_env="$(mktemp "${BOT_ENV_DIR}/bot.env.staged.XXXXXX")"
  if [[ -f "${BOT_ENV_FILE}" ]]; then
    cp "${BOT_ENV_FILE}" "${staged_env}"
  fi

  set_env_value TELEGRAM_BOT_TOKEN "${final_token}" "${staged_env}"
  set_env_value INTERNAL_SHARED_SECRET "${final_secret}" "${staged_env}"
  set_env_value TELEGRAM_BOT_USERNAME "${bot_username}" "${staged_env}"
  set_env_value TELEGRAM_DEFAULT_CHAT_ID "${default_chat_id}" "${staged_env}"
  set_env_value TELEGRAM_ADMIN_CHAT_IDS "${admin_chat_ids}" "${staged_env}"
  set_env_value TELEGRAM_ADMIN_USER_IDS "${admin_user_ids}" "${staged_env}"
  set_env_value TELEGRAM_ALLOW_UNRESTRICTED_ACCESS "false" "${staged_env}"

  set_env_value BOT_HOME "${BOT_HOME}" "${staged_env}"
  set_env_value BOT_ENV_FILE "${BOT_ENV_FILE}" "${staged_env}"
  set_env_value BOT_STATE_DIR "${BOT_STATE_DIR}" "${staged_env}"
  set_env_value BOT_LOG_DIR "${BOT_LOG_DIR}" "${staged_env}"
  set_env_value GATEWAY_RUN_USER "${GATEWAY_RUN_USER}" "${staged_env}"
  set_env_value BACKEND_BASE_URL "${BACKEND_BASE_URL}" "${staged_env}"
  set_env_value BACKEND_HOST "${BACKEND_HOST}" "${staged_env}"
  set_env_value BACKEND_PORT "${BACKEND_PORT}" "${staged_env}"
  set_env_value COMMANDS_FILE "${BOT_HOME}/shared/commands.json" "${staged_env}"

  chmod 600 "${staged_env}" || true
  mv -f "${staged_env}" "${BOT_ENV_FILE}"
  chmod 600 "${BOT_ENV_FILE}" || true
  if ! validate_required_env; then
    warn "Konfigurasi env tersimpan tetapi belum valid. Lengkapi field wajib sebelum restart service."
    return 1
  fi
  ok "Konfigurasi env selesai."
}

change_telegram_token() {
  need_root
  ensure_env_file

  local current masked new_token confirm
  current="$(get_env_value TELEGRAM_BOT_TOKEN "${BOT_ENV_FILE}")"
  masked="$(mask_secret "${current}")"

  echo "Token saat ini: ${masked}"
  new_token="$(prompt_secret_or_back "Masukkan token Telegram baru")"
  if [[ "${new_token}" == "${BACK_INPUT_SENTINEL}" ]]; then
    warn "Ganti token dibatalkan (kembali)."
    return 0
  fi
  [[ -n "${new_token}" ]] || die "Token baru tidak boleh kosong."

  confirm="$(prompt_secret_or_back "Ulangi token untuk konfirmasi")"
  if [[ "${confirm}" == "${BACK_INPUT_SENTINEL}" ]]; then
    warn "Ganti token dibatalkan (kembali)."
    return 0
  fi
  [[ "${new_token}" == "${confirm}" ]] || die "Konfirmasi token tidak sama."

  set_env_value TELEGRAM_BOT_TOKEN "${new_token}" "${BOT_ENV_FILE}"
  chmod 600 "${BOT_ENV_FILE}" || true
  ok "Token berhasil diperbarui di ${BOT_ENV_FILE}."

  local restart_rc=0
  if prompt_yes_no_or_back "Restart service bot sekarang"; then
    start_or_restart_services
  else
    restart_rc=$?
    if (( restart_rc == 2 )); then
      warn "Lewati restart service (kembali)."
    fi
  fi
}

validate_source_tree() {
  local src="$1"
  [[ -d "${src}" ]] || die "Source bot tidak ditemukan: ${src}"
  [[ -f "${src}/gateway-py/requirements.txt" ]] || die "Source invalid: gateway-py/requirements.txt tidak ditemukan"
  [[ -f "${src}/gateway-py/requirements.lock.txt" ]] || die "Source invalid: gateway-py/requirements.lock.txt tidak ditemukan"
  [[ -f "${src}/gateway-py/app/main.py" ]] || die "Source invalid: gateway-py/app/main.py tidak ditemukan"
  [[ -f "${src}/backend-py/requirements.txt" ]] || die "Source invalid: backend-py/requirements.txt tidak ditemukan"
  [[ -f "${src}/backend-py/requirements.lock.txt" ]] || die "Source invalid: backend-py/requirements.lock.txt tidak ditemukan"
  [[ -f "${src}/shared/commands.json" ]] || die "Source invalid: shared/commands.json tidak ditemukan"
  [[ -f "${src}/systemd/bot-telegram-backend.service.tpl" ]] || die "Source invalid: template backend service tidak ditemukan"
  [[ -f "${src}/systemd/bot-telegram-gateway.service.tpl" ]] || die "Source invalid: template gateway service tidak ditemukan"
}

source_tree_valid() {
  local src="$1"
  [[ -d "${src}" ]] || return 1
  [[ -f "${src}/gateway-py/requirements.txt" ]] || return 1
  [[ -f "${src}/gateway-py/requirements.lock.txt" ]] || return 1
  [[ -f "${src}/gateway-py/app/main.py" ]] || return 1
  [[ -f "${src}/backend-py/requirements.txt" ]] || return 1
  [[ -f "${src}/backend-py/requirements.lock.txt" ]] || return 1
  [[ -f "${src}/shared/commands.json" ]] || return 1
  [[ -f "${src}/systemd/bot-telegram-backend.service.tpl" ]] || return 1
  [[ -f "${src}/systemd/bot-telegram-gateway.service.tpl" ]] || return 1
}

discover_local_source_dir() {
  local candidate
  local candidates=(
    "${SRC_LOCAL_DIR}"
    "${SCRIPT_DIR}/bot-telegram"
    "${SCRIPT_DIR}/../bot-telegram"
    "${BOT_HOME}"
  )

  for candidate in "${candidates[@]}"; do
    [[ -n "${candidate}" ]] || continue
    if source_tree_valid "${candidate}"; then
      printf '%s\n' "${candidate}"
      return 0
    fi
  done
  return 1
}

resolve_source_dir_from_extract() {
  local base="$1"
  local candidate

  if source_tree_valid "${base}"; then
    printf '%s\n' "${base}"
    return 0
  fi

  for candidate in "${base}"/*; do
    [[ -d "${candidate}" ]] || continue
    if source_tree_valid "${candidate}/bot-telegram"; then
      printf '%s\n' "${candidate}/bot-telegram"
      return 0
    fi
    if source_tree_valid "${candidate}"; then
      printf '%s\n' "${candidate}"
      return 0
    fi
  done

  return 1
}

resolve_nologin_shell() {
  local shell
  shell="$(command -v nologin 2>/dev/null || true)"
  [[ -n "${shell}" ]] || shell="/usr/sbin/nologin"
  printf '%s\n' "${shell}"
}

gateway_service_group() {
  id -gn "${GATEWAY_RUN_USER}" 2>/dev/null || true
}

ensure_gateway_service_user() {
  local nologin_bin
  if id -u "${GATEWAY_RUN_USER}" >/dev/null 2>&1; then
    return 0
  fi

  nologin_bin="$(resolve_nologin_shell)"
  if getent group "${GATEWAY_RUN_USER}" >/dev/null 2>&1; then
    useradd --system --gid "${GATEWAY_RUN_USER}" --home-dir "${BOT_STATE_DIR}" --no-create-home --shell "${nologin_bin}" "${GATEWAY_RUN_USER}" >/dev/null 2>&1 \
      || die "Gagal membuat user service gateway ${GATEWAY_RUN_USER}."
    return 0
  fi

  useradd --system --user-group --home-dir "${BOT_STATE_DIR}" --no-create-home --shell "${nologin_bin}" "${GATEWAY_RUN_USER}" >/dev/null 2>&1 \
    || die "Gagal membuat user service gateway ${GATEWAY_RUN_USER}."
}

prepare_gateway_runtime_permissions() {
  local gateway_group archives_dir safety_dir tmp_dir uploads_dir monitor_log_file monitor_lock_file
  gateway_group="$(gateway_service_group)"
  [[ -n "${gateway_group}" ]] || gateway_group="${GATEWAY_RUN_USER}"
  archives_dir="${BOT_STATE_DIR}/backups/archives"
  safety_dir="${BOT_STATE_DIR}/backups/safety"
  tmp_dir="${BOT_STATE_DIR}/tmp"
  uploads_dir="${tmp_dir}/uploads"
  monitor_log_file="${BOT_LOG_DIR}/monitor-lite.log"
  monitor_lock_file="${BOT_LOG_DIR}/monitor-lite.lock"

  install -d -m 750 -o root -g "${gateway_group}" "${BOT_STATE_DIR}" "${BOT_STATE_DIR}/backups" "${tmp_dir}"
  install -d -m 750 -o "${GATEWAY_RUN_USER}" -g "${gateway_group}" "${BOT_LOG_DIR}"
  install -d -m 2750 -o root -g "${gateway_group}" "${archives_dir}"
  install -d -m 700 -o root -g root "${safety_dir}"
  install -d -m 2770 -o "${GATEWAY_RUN_USER}" -g "${gateway_group}" "${uploads_dir}"

  if [[ -n "${gateway_group}" && -d "${archives_dir}" ]]; then
    chgrp -R "${gateway_group}" "${archives_dir}" >/dev/null 2>&1 || true
    find "${archives_dir}" -type d -exec chmod 2750 {} + >/dev/null 2>&1 || true
    find "${archives_dir}" -type f -exec chmod 640 {} + >/dev/null 2>&1 || true
  fi
  if [[ -f "${monitor_log_file}" ]]; then
    chown "${GATEWAY_RUN_USER}:${gateway_group}" "${monitor_log_file}" || true
    chmod 640 "${monitor_log_file}" || true
  fi
  if [[ -f "${monitor_lock_file}" ]]; then
    chown "${GATEWAY_RUN_USER}:${gateway_group}" "${monitor_lock_file}" || true
    chmod 640 "${monitor_lock_file}" || true
  fi
  mark_bot_owned_dir "${BOT_STATE_DIR}"
  mark_bot_owned_dir "${BOT_LOG_DIR}"
}

extract_source_archive() {
  local archive="$1"
  local dst="$2"
  local archive_lower
  archive_lower="$(echo "${archive}" | tr '[:upper:]' '[:lower:]')"

  if [[ "${archive_lower}" == *.zip ]]; then
    python3 - "${archive}" "${dst}" <<'PY' || die "Gagal extract archive zip."
import os
import shutil
import stat
import sys
import zipfile

archive_path = sys.argv[1]
dest_path = sys.argv[2]
dest_real = os.path.realpath(dest_path)

def safe_target(base_real: str, member_name: str):
  name = member_name.replace("\\", "/")
  if "\x00" in name:
    raise ValueError("zip entry contains NUL byte")
  normalized = os.path.normpath(name).lstrip("/")
  if normalized in ("", "."):
    return None
  if normalized == ".." or normalized.startswith("../"):
    raise ValueError(f"unsafe zip entry path: {member_name}")
  target = os.path.realpath(os.path.join(base_real, normalized))
  if target != base_real and not target.startswith(base_real + os.sep):
    raise ValueError(f"zip entry escapes destination: {member_name}")
  return target

with zipfile.ZipFile(archive_path, "r") as zf:
  for member in zf.infolist():
    target = safe_target(dest_real, member.filename)
    if target is None:
      continue
    mode = (member.external_attr >> 16) & 0o170000
    if mode in (stat.S_IFLNK, stat.S_IFCHR, stat.S_IFBLK, stat.S_IFIFO, stat.S_IFSOCK):
      raise ValueError(f"unsupported zip entry type: {member.filename}")
    if member.is_dir():
      os.makedirs(target, exist_ok=True)
      continue
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with zf.open(member, "r") as src, open(target, "wb") as dst:
      shutil.copyfileobj(src, dst)
PY
    return 0
  fi

  python3 - "${archive}" "${dst}" <<'PY' || die "Gagal extract archive tar.gz."
import os
import shutil
import sys
import tarfile

archive_path = sys.argv[1]
dest_path = sys.argv[2]
dest_real = os.path.realpath(dest_path)

def safe_target(base_real: str, member_name: str):
  name = member_name.replace("\\", "/")
  if "\x00" in name:
    raise ValueError("tar entry contains NUL byte")
  normalized = os.path.normpath(name).lstrip("/")
  if normalized in ("", "."):
    return None
  if normalized == ".." or normalized.startswith("../"):
    raise ValueError(f"unsafe tar entry path: {member_name}")
  target = os.path.realpath(os.path.join(base_real, normalized))
  if target != base_real and not target.startswith(base_real + os.sep):
    raise ValueError(f"tar entry escapes destination: {member_name}")
  return target

with tarfile.open(archive_path, "r:*") as tf:
  for member in tf.getmembers():
    if member.issym() or member.islnk() or member.isdev():
      raise ValueError(f"unsupported tar entry type: {member.name}")
    target = safe_target(dest_real, member.name)
    if target is None:
      continue
    if member.isdir():
      os.makedirs(target, exist_ok=True)
      continue
    if not member.isfile():
      raise ValueError(f"unsupported tar entry type: {member.name}")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    extracted = tf.extractfile(member)
    if extracted is None:
      raise ValueError(f"failed to read tar entry: {member.name}")
    with extracted, open(target, "wb") as dst:
      shutil.copyfileobj(extracted, dst)
PY
}

deploy_or_update_files() {
  need_root

  local cmd
  for cmd in curl tar rsync python3; do
    command_exists "${cmd}" || die "Dependency '${cmd}' belum tersedia. Jalankan menu 2) Install Dependencies."
  done

  local tmp archive src_dir archive_ext archive_url_no_query local_source_dir
  local bot_home_parent stage_dir previous_dir=""
  local_source_dir="$(discover_local_source_dir || true)"

  if [[ -n "${local_source_dir}" ]]; then
    log "Menggunakan source lokal: ${local_source_dir}"
    src_dir="${local_source_dir}"
    validate_source_tree "${src_dir}"
  else
    tmp="$(mktemp -d /tmp/bot-telegram-src.XXXXXX)"
  archive_url_no_query="${SRC_ARCHIVE_URL%%\?*}"
  archive_ext="tar.gz"
  if [[ "${archive_url_no_query,,}" == *.zip ]]; then
    archive_ext="zip"
  fi
  archive="${tmp}/src.${archive_ext}"

  log "Download source archive: ${SRC_ARCHIVE_URL}"
  curl -fsSL --connect-timeout 15 --max-time 180 "${SRC_ARCHIVE_URL}" -o "${archive}" || die "Gagal download archive source."

  log "Extract archive..."
  extract_source_archive "${archive}" "${tmp}"
    src_dir="$(resolve_source_dir_from_extract "${tmp}")" || die "Tidak menemukan source bot Telegram yang valid di archive."
    validate_source_tree "${src_dir}"
  fi

  bot_home_parent="$(dirname "${BOT_HOME}")"
  mkdir -p "${bot_home_parent}" "${BOT_STATE_DIR}" "${BOT_LOG_DIR}" "${BOT_ENV_DIR}"
  stage_dir="$(mktemp -d "${bot_home_parent}/.bot-telegram.stage.XXXXXX")"

  log "Sync source ke staging ${stage_dir}"
  rsync -a --delete \
    --exclude '.env' \
    --exclude '.venv' \
    --exclude '__pycache__' \
    --exclude '*.pyc' \
    --filter='+ /runtime/logs/.gitkeep' \
    --filter='+ /runtime/tmp/.gitkeep' \
    --filter='- /runtime/logs/***' \
    --filter='- /runtime/tmp/***' \
    "${src_dir}/" "${stage_dir}/"

  if [[ -n "${tmp:-}" ]]; then
    rm -rf "${tmp}" >/dev/null 2>&1 || true
    tmp=""
  fi

  log "Install dependency Python backend"
  python3 -m venv "${stage_dir}/.venv"
  "${stage_dir}/.venv/bin/pip" install --upgrade pip >/dev/null
  "${stage_dir}/.venv/bin/pip" install -r "${stage_dir}/backend-py/requirements.lock.txt"
  "${stage_dir}/.venv/bin/pip" install -r "${stage_dir}/gateway-py/requirements.lock.txt"

  log "Validasi syntax Python (backend + gateway)"
  local backend_py_files=() gateway_py_files=()
  mapfile -t backend_py_files < <(find "${stage_dir}/backend-py/app" -name '*.py')
  mapfile -t gateway_py_files < <(find "${stage_dir}/gateway-py/app" -name '*.py')
  if (( ${#backend_py_files[@]} > 0 )); then
    python3 -m py_compile "${backend_py_files[@]}"
  fi
  if (( ${#gateway_py_files[@]} > 0 )); then
    python3 -m py_compile "${gateway_py_files[@]}"
  fi

  ensure_env_file

  chmod -R go-rwx "${BOT_ENV_DIR}" || true

  if [[ -e "${BOT_HOME}" ]]; then
    previous_dir="${bot_home_parent}/.bot-telegram.prev.$(date +%Y%m%d%H%M%S)"
    mv "${BOT_HOME}" "${previous_dir}" || die "Gagal memindahkan instalasi bot lama ke backup: ${BOT_HOME}"
  fi

  if ! mv "${stage_dir}" "${BOT_HOME}"; then
    rm -rf "${stage_dir}" >/dev/null 2>&1 || true
    if [[ -n "${previous_dir}" && -e "${previous_dir}" ]]; then
      mv "${previous_dir}" "${BOT_HOME}" >/dev/null 2>&1 || true
    fi
    die "Gagal mengaktifkan instalasi bot Telegram baru."
  fi
  stage_dir=""
  mark_bot_owned_dir "${BOT_HOME}"

  if [[ -n "${previous_dir}" && -e "${previous_dir}" ]]; then
    rm -rf "${previous_dir}" >/dev/null 2>&1 || true
  fi

  ok "Deploy/update bot files selesai."
}

install_or_update_systemd() {
  need_root
  command_exists systemctl || die "systemctl tidak tersedia di host ini."

  local backend_tpl gateway_tpl monitor_tpl monitor_timer_tpl
  local backend_dst gateway_dst monitor_dst monitor_timer_dst
  backend_tpl="${BOT_HOME}/systemd/bot-telegram-backend.service.tpl"
  gateway_tpl="${BOT_HOME}/systemd/bot-telegram-gateway.service.tpl"
  monitor_tpl="${BOT_HOME}/systemd/${MONITOR_SERVICE}.service.tpl"
  monitor_timer_tpl="${BOT_HOME}/systemd/${MONITOR_SERVICE}.timer.tpl"
  backend_dst="/etc/systemd/system/${BACKEND_SERVICE}.service"
  gateway_dst="/etc/systemd/system/${GATEWAY_SERVICE}.service"
  monitor_dst="/etc/systemd/system/${MONITOR_SERVICE}.service"
  monitor_timer_dst="/etc/systemd/system/${MONITOR_SERVICE}.timer"

  [[ -f "${backend_tpl}" ]] || die "Template tidak ditemukan: ${backend_tpl}"
  [[ -f "${gateway_tpl}" ]] || die "Template tidak ditemukan: ${gateway_tpl}"

  ensure_gateway_service_user
  prepare_gateway_runtime_permissions

  sed \
    -e "s#/opt/bot-telegram#${BOT_HOME}#g" \
    -e "s#/etc/bot-telegram/bot.env#${BOT_ENV_FILE}#g" \
    "${backend_tpl}" > "${backend_dst}"

  sed \
    -e "s#/opt/bot-telegram#${BOT_HOME}#g" \
    -e "s#/etc/bot-telegram/bot.env#${BOT_ENV_FILE}#g" \
    -e "s#User=bot-telegram-gateway#User=${GATEWAY_RUN_USER}#g" \
    "${gateway_tpl}" > "${gateway_dst}"

  if [[ -f "${monitor_tpl}" ]]; then
    sed \
      -e "s#/opt/bot-telegram#${BOT_HOME}#g" \
      -e "s#/etc/bot-telegram/bot.env#${BOT_ENV_FILE}#g" \
      -e "s#User=bot-telegram-gateway#User=${GATEWAY_RUN_USER}#g" \
      "${monitor_tpl}" > "${monitor_dst}"
  fi

  if [[ -f "${monitor_timer_tpl}" ]]; then
    sed \
      -e "s#/opt/bot-telegram#${BOT_HOME}#g" \
      -e "s#/etc/bot-telegram/bot.env#${BOT_ENV_FILE}#g" \
      "${monitor_timer_tpl}" > "${monitor_timer_dst}"
  fi

  chmod 644 "${backend_dst}" "${gateway_dst}"
  [[ -f "${monitor_dst}" ]] && chmod 644 "${monitor_dst}"
  [[ -f "${monitor_timer_dst}" ]] && chmod 644 "${monitor_timer_dst}"

  systemctl daemon-reload
  systemctl enable "${BACKEND_SERVICE}" "${GATEWAY_SERVICE}" >/dev/null 2>&1 || die "Gagal enable service backend/gateway."
  if [[ -f "${monitor_dst}" && -f "${monitor_timer_dst}" ]]; then
    systemctl enable "${MONITOR_SERVICE}.timer" >/dev/null 2>&1 || die "Gagal enable monitor timer."
    systemctl restart "${MONITOR_SERVICE}.timer" >/dev/null 2>&1 || die "Gagal restart monitor timer."
  fi

  ok "Systemd service terpasang/terupdate."
  show_service_status "${BACKEND_SERVICE}"
  show_service_status "${GATEWAY_SERVICE}"
  if [[ -f "${monitor_dst}" && -f "${monitor_timer_dst}" ]]; then
    show_service_status "${MONITOR_SERVICE}.timer"
  fi
}

start_or_restart_services() {
  need_root
  command_exists systemctl || die "systemctl tidak tersedia di host ini."
  validate_required_env || die "Env belum valid. Jalankan menu 3 (Configure Bot) dulu."

  service_unit_exists "${BACKEND_SERVICE}" || die "Service ${BACKEND_SERVICE}.service belum terpasang. Jalankan menu 6 dulu."
  service_unit_exists "${GATEWAY_SERVICE}" || die "Service ${GATEWAY_SERVICE}.service belum terpasang. Jalankan menu 6 dulu."

  restart_unit_checked "${BACKEND_SERVICE}.service"
  wait_for_backend_ready
  restart_unit_checked "${GATEWAY_SERVICE}.service"
  if timer_unit_exists "${MONITOR_SERVICE}"; then
    restart_unit_checked "${MONITOR_SERVICE}.timer"
  fi

  ok "Service bot di-restart."
  show_service_status "${BACKEND_SERVICE}"
  show_service_status "${GATEWAY_SERVICE}"
  if timer_unit_exists "${MONITOR_SERVICE}"; then
    show_service_status "${MONITOR_SERVICE}.timer"
  fi
}

status_services() {
  need_root
  command_exists systemctl || die "systemctl tidak tersedia di host ini."

  echo "Status service bot Telegram"
  hr
  show_service_status "${BACKEND_SERVICE}"
  show_service_status "${GATEWAY_SERVICE}"
  if timer_unit_exists "${MONITOR_SERVICE}"; then
    show_service_status "${MONITOR_SERVICE}.timer"
  fi
  hr

  local token
  token="$(get_env_value TELEGRAM_BOT_TOKEN "${BOT_ENV_FILE}")"
  echo "Env file : ${BOT_ENV_FILE}"
  echo "Token    : $(mask_secret "${token}")"
  echo "Bot home : ${BOT_HOME}"
}

wait_for_backend_ready() {
  need_root
  command_exists curl || die "curl tidak tersedia di host ini."

  local secret_url secret_value attempts
  secret_value="$(get_env_value INTERNAL_SHARED_SECRET "${BOT_ENV_FILE}")"
  [[ -n "${secret_value}" ]] || die "INTERNAL_SHARED_SECRET belum diisi di ${BOT_ENV_FILE}."

  secret_url="${BACKEND_BASE_URL%/}/api/main-menu"
  attempts=40

  for _ in $(seq 1 "${attempts}"); do
    if curl -fsS --max-time 5 --config - "${secret_url}" >/dev/null 2>&1 <<EOF
header = "X-Internal-Shared-Secret: ${secret_value}"
EOF
    then
      ok "Backend bot siap menerima koneksi."
      return 0
    fi
    sleep 1
  done

  die "Backend bot belum siap di ${secret_url} setelah ${attempts} detik."
}

view_logs_menu() {
  need_root
  command_exists journalctl || die "journalctl tidak tersedia."

  local c lines
  lines="$(prompt_with_default "Jumlah baris log" "80")"
  [[ "${lines}" =~ ^[0-9]+$ ]] || lines="80"

  echo "Pilih log service:"
  echo "  1) ${BACKEND_SERVICE}"
  echo "  2) ${GATEWAY_SERVICE}"
  echo "  3) Keduanya"
  echo "  0) Kembali"
  read -r -p "Pilih: " c || true

  case "${c}" in
    1)
      journalctl -u "${BACKEND_SERVICE}" --no-pager -n "${lines}" || true
      ;;
    2)
      journalctl -u "${GATEWAY_SERVICE}" --no-pager -n "${lines}" || true
      ;;
    3)
      journalctl -u "${BACKEND_SERVICE}" --no-pager -n "${lines}" || true
      hr
      journalctl -u "${GATEWAY_SERVICE}" --no-pager -n "${lines}" || true
      ;;
    0|back|kembali|k|b)
      return 0
      ;;
    *)
      warn "Pilihan tidak valid."
      ;;
  esac
}

uninstall_bot() {
  need_root
  command_exists systemctl || die "systemctl tidak tersedia di host ini."

  echo "Anda akan menghapus instalasi bot Telegram secara bersih dari sistem ini."
  echo "- Service: ${BACKEND_SERVICE}, ${GATEWAY_SERVICE}, ${MONITOR_SERVICE}.timer"
  echo "- Bot home: ${BOT_HOME}"
  echo "- Env file: ${BOT_ENV_FILE}"
  echo "- Runtime : ${BOT_STATE_DIR}, ${BOT_LOG_DIR}"
  echo "- Package OS/runtime (python/dll): TIDAK dihapus"
  read -r -p "Ketik HAPUS untuk lanjut (atau kembali): " confirm || true
  if is_back_choice "${confirm}"; then
    warn "Batal uninstall (kembali)."
    return 0
  fi
  [[ "${confirm}" == "HAPUS" ]] || {
    warn "Batal uninstall."
    return 0
  }

  stop_unit_checked "${BACKEND_SERVICE}.service"
  stop_unit_checked "${GATEWAY_SERVICE}.service"
  stop_unit_checked "${MONITOR_SERVICE}.timer"
  stop_unit_checked "${MONITOR_SERVICE}.service"
  disable_unit_checked "${BACKEND_SERVICE}.service"
  disable_unit_checked "${GATEWAY_SERVICE}.service"
  disable_unit_checked "${MONITOR_SERVICE}.timer"
  rm -f \
    "/etc/systemd/system/${BACKEND_SERVICE}.service" \
    "/etc/systemd/system/${GATEWAY_SERVICE}.service" \
    "/etc/systemd/system/${MONITOR_SERVICE}.service" \
    "/etc/systemd/system/${MONITOR_SERVICE}.timer" >/dev/null 2>&1 || true

  rm -rf \
    "/etc/systemd/system/${BACKEND_SERVICE}.service.d" \
    "/etc/systemd/system/${GATEWAY_SERVICE}.service.d" \
    "/etc/systemd/system/${MONITOR_SERVICE}.service.d" \
    "/etc/systemd/system/${MONITOR_SERVICE}.timer.d" >/dev/null 2>&1 || true

  systemctl daemon-reload || true
  systemctl reset-failed "${BACKEND_SERVICE}" "${GATEWAY_SERVICE}" "${MONITOR_SERVICE}" >/dev/null 2>&1 || true

  assert_safe_delete_target "${BOT_HOME}" "BOT_HOME"
  assert_safe_delete_target "${BOT_ENV_DIR}" "BOT_ENV_DIR"
  assert_safe_delete_target "${BOT_STATE_DIR}" "BOT_STATE_DIR"
  assert_safe_delete_target "${BOT_LOG_DIR}" "BOT_LOG_DIR"

  rm -rf "${BOT_HOME}"

  if [[ -f "${BOT_ENV_DIR}/${BOT_DIR_MARKER}" ]]; then
    rm -rf "${BOT_ENV_DIR}"
  else
    rm -f "${BOT_ENV_FILE}" "${BOT_ENV_DIR}/${BOT_DIR_MARKER}"
    rmdir --ignore-fail-on-non-empty "${BOT_ENV_DIR}" >/dev/null 2>&1 || true
  fi

  if [[ -f "${BOT_STATE_DIR}/${BOT_DIR_MARKER}" ]]; then
    rm -rf "${BOT_STATE_DIR}"
  else
    rm -rf "${BOT_STATE_DIR}/backups" "${BOT_STATE_DIR}/tmp"
    rm -f "${BOT_STATE_DIR}/${BOT_DIR_MARKER}"
    rmdir --ignore-fail-on-non-empty "${BOT_STATE_DIR}" >/dev/null 2>&1 || true
  fi

  if [[ -f "${BOT_LOG_DIR}/${BOT_DIR_MARKER}" ]]; then
    rm -rf "${BOT_LOG_DIR}"
  else
    rm -f "${BOT_LOG_DIR}/monitor-lite.log" "${BOT_LOG_DIR}/monitor-lite.lock" "${BOT_LOG_DIR}/${BOT_DIR_MARKER}"
    rmdir --ignore-fail-on-non-empty "${BOT_LOG_DIR}" >/dev/null 2>&1 || true
  fi
  rm -rf /tmp/bot-telegram-src.* >/dev/null 2>&1 || true

  ok "Uninstall bersih selesai (package OS/runtime tetap terpasang)."
}

quick_setup_all_in_one() {
  need_root
  echo "Quick Setup akan menjalankan:"
  echo "1) Install dependencies"
  echo "2) Configure env/token"
  echo "3) Deploy/update source ke ${BOT_HOME}"
  echo "4) Install/update systemd"
  echo "5) Start/restart service"
  hr

  local quick_rc=0
  if prompt_yes_no_or_back "Lanjutkan Quick Setup sekarang"; then
    :
  else
    quick_rc=$?
    if (( quick_rc == 2 )); then
      warn "Quick setup dibatalkan (kembali)."
      return 0
    fi
    warn "Quick setup dibatalkan."
    return 0
  fi

  install_dependencies
  configure_env_interactive
  if (( CONFIGURE_ENV_CANCELLED == 1 )); then
    warn "Quick setup dihentikan karena konfigurasi env dibatalkan (kembali)."
    return 0
  fi
  validate_required_env || die "Env belum lengkap. Isi dulu data wajib."
  deploy_or_update_files
  install_or_update_systemd
  start_or_restart_services
  status_services

  ok "Quick setup selesai."
}

show_header() {
  safe_clear
  echo -e "${UI_BOLD}${UI_ACCENT}Xray Telegram Bot Installer${UI_RESET}"
  echo -e "${UI_MUTED}Host: $(hostname) | Script: ${0##*/}${UI_RESET}"
  hr
  echo -e "${UI_BOLD}${UI_ACCENT}Main Menu${UI_RESET}"
  echo -e "${UI_MUTED}Target deploy : ${BOT_HOME}${UI_RESET}"
  echo -e "${UI_MUTED}Env file      : ${BOT_ENV_FILE}${UI_RESET}"
  echo -e "${UI_MUTED}Source archive: ${SRC_ARCHIVE_URL}${UI_RESET}"
  hr
}

menu_loop() {
  need_root
  while true; do
    show_header
    echo -e "  ${UI_ACCENT}1)${UI_RESET} Quick Setup Bot Telegram (All-in-One)"
    echo -e "  ${UI_ACCENT}2)${UI_RESET} Install Dependencies"
    echo -e "  ${UI_ACCENT}3)${UI_RESET} Configure Bot (.env)"
    echo -e "  ${UI_ACCENT}4)${UI_RESET} Ganti Telegram Bot Token"
    echo -e "  ${UI_ACCENT}5)${UI_RESET} Deploy/Update Bot Files"
    echo -e "  ${UI_ACCENT}6)${UI_RESET} Install/Update systemd Services"
    echo -e "  ${UI_ACCENT}7)${UI_RESET} Start/Restart Services"
    echo -e "  ${UI_ACCENT}8)${UI_RESET} Status Services"
    echo -e "  ${UI_ACCENT}9)${UI_RESET} View Logs"
    echo -e " ${UI_ACCENT}10)${UI_RESET} Uninstall Bot (Clean, keep packages)"
    echo -e "  ${UI_ACCENT}0)${UI_RESET} Kembali"
    hr
    if ! read -r -p "Pilih: " c; then
      echo
      return 0
    fi

    case "${c}" in
      1) run_action "Quick Setup Bot Telegram" quick_setup_all_in_one; pause ;;
      2) run_action "Install Dependencies" install_dependencies; pause ;;
      3) run_action "Configure Bot (.env)" configure_env_interactive; pause ;;
      4) run_action "Ganti Telegram Bot Token" change_telegram_token; pause ;;
      5) run_action "Deploy/Update Bot Files" deploy_or_update_files; pause ;;
      6) run_action "Install/Update systemd Services" install_or_update_systemd; pause ;;
      7) run_action "Start/Restart Services" start_or_restart_services; pause ;;
      8) run_action "Status Services" status_services; pause ;;
      9) run_action "View Logs" view_logs_menu; pause ;;
      10) run_action "Uninstall Bot" uninstall_bot; pause ;;
      0|back|kembali|k|b) return 0 ;;
      *) warn "Pilihan tidak valid."; sleep 1 ;;
    esac
  done
}

usage() {
  cat <<USAGE
Usage:
  $0 menu
  $0 quick-setup
  $0 install-deps
  $0 configure-env
  $0 update-token
  $0 deploy
  $0 install-systemd
  $0 restart
  $0 status
  $0 logs
  $0 uninstall
USAGE
}

main() {
  local cmd="${1:-menu}"
  case "${cmd}" in
    -h|--help|help)
      usage
      return 0
      ;;
  esac
  need_root
  telegram_license_guard_preflight "${cmd}"
  case "${cmd}" in
    menu) menu_loop ;;
    quick-setup) quick_setup_all_in_one ;;
    install-deps) install_dependencies ;;
    configure-env) configure_env_interactive ;;
    update-token) change_telegram_token ;;
    deploy) deploy_or_update_files ;;
    install-systemd) install_or_update_systemd ;;
    restart) start_or_restart_services ;;
    status) status_services ;;
    logs) view_logs_menu ;;
    uninstall) uninstall_bot ;;
    *) usage; die "Command tidak dikenal: ${cmd}" ;;
  esac
}

main "$@"
